# Dissertation
My code for testing the planarity and rigidity of graphs will be committed here frequently
